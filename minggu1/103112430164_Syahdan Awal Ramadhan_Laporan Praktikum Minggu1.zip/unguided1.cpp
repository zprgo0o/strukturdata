#include <iostream>
using namespace std;

int main() {
    float a, b;

    cout << "Masukkan bilangan pertama: ";
    cin >> a;
    cout << "Masukkan bilangan kedua: ";
    cin >> b;

    cout << "\nHasil operasi:" << endl;
    cout << a << " + " << b << " = " << (a + b) << endl;
    cout << a << " - " << b << " = " << (a - b) << endl;
    cout << a << " * " << b << " = " << (a * b) << endl;

    if (b != 0) {
        cout << a << " / " << b << " = " << (a / b) << endl;
    } else {
        cout << "Pembagian tidak bisa dilakukan karena pembagi = 0" << endl;
    }

    return 0;
}
