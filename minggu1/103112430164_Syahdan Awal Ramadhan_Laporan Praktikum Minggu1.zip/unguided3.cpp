#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Masukkan angka: ";
    cin >> n;

    for (int i = n; i >= 1; i--) {
        // cetak angka menurun
        for (int j = i; j >= 1; j--) {
            cout << j;
        }

        cout << "*";

        // cetak angka menaik
        for (int j = 1; j <= i; j++) {
            cout << j;
        }
        cout << endl;
    }
    cout << "*" << endl; // cetak bintang terakhir

    return 0;
}